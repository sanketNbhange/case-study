package com.cybage;

//we cannot instantiate class, common properties for subclasses can be stored in abstract classes
public abstract class Account {

	private String accNumber;
	private String accType;
	private String custId;
	private double balance;

	public Account() {
		super();
	}

	public Account(String accNumber, String accType, String custId, double balance) {
		super();
		this.accNumber = accNumber;
		this.accType = accType;
		this.custId = custId;
		this.balance = balance;
	}

	public String getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Account [accNumber=" + accNumber + ", accType=" + accType + ", custId=" + custId + ", balance="
				+ balance + "]";
	} 
}