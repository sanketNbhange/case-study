package com.cybage;

public class AccountException extends Exception{
	//override constructor
	public AccountException(String msg) {
		super(msg);
 	}
}
