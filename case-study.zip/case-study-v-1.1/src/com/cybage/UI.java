package com.cybage;

import java.util.Scanner;

import com.cybage.dbutil.DbUtil;

public class UI {
	public static void main(String[] args) throws Exception{
		System.out.println("Welcome to HDFC bank");

		BankingService bs = new BankingService();
		//value will come from html page from user
		bs.openAccount(AccountType.CURRENT.toString(), "dm102", "pune123", 40000);

		//getting balance
		System.out.println("avaliable balance: " + bs.getBalance("H6762"));			
	}
}