package com.cybage;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.cybage.dao.AccountDao;
import com.cybage.dao.AccountDaoImpl;
import com.cybage.dbutil.DbUtil;

//this class is specific certain project
public class BankingService implements Banking{

	CustomerService cs = new CustomerService();
	AccountDao dao = new AccountDaoImpl();
	
	public String generateAccNumber(){
		return "H"+ Math.round(Math.random()*99999);
	}
	@Override
	public String openAccount(String accType,
			String name, 
			String address, 
			double balance) throws AccountException, Exception
	{		
		if(balance < 10000){
			throw new AccountException("Cannot create account as amount is less than 10000");
		}
		 

		//1. create customer
		Customer c1 = cs.addCustomer(name, address);
		//store customer in database
		//logically this code should go to customerdao
		String sql = "insert into customer values(?, ?, ?)";
		Connection con = DbUtil.getConnection();			//new object
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, c1.getCustId());
		ps.setString(2, c1.getCustName());
		ps.setString(3, c1.getCustAddress());
		ps.executeUpdate();	
		
		
		//need to create account and store in database
		Account account = null;
		switch (accType) {
		case "SAVING":	
			account = new SavingAccount(generateAccNumber(), accType, c1.getCustId(), balance);
			break;
		case "CURRENT":
			account = new CurrentAccount(generateAccNumber(), accType, c1.getCustId(), balance);
			break;
		default: 
			account = null;
		}
		ps.close();
		con.close();
		return dao.addAccount(account);
	}
	@Override
	public double getBalance(String accNumber) throws AccountException, Exception{
		return dao.getBalance(accNumber);		
	}
	
	@Override
	public double withdrawl(String accNumber, double amount) throws AccountException {
		double availableBalance  = 0;
		double tempBalance = 0;
		boolean found = false;
		
//		for(Account account: accounts){
//			if(account.getAccNumber().equals(accNumber)){
//				availableBalance = account.getBalance();
//				tempBalance = availableBalance - amount;
//				if(tempBalance < 10000){
//					throw new AccountException("Cannot withdrawl as effective balance goes below 10000");
//				}else{
//					account.setBalance(tempBalance);
//				}
//				found = true;
//				break;
//			}
//		}
		if(found) return tempBalance;
		else {
			throw new AccountException("Account does not exists");
		}
	}
}