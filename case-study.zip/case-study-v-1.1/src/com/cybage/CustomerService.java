package com.cybage;

public class CustomerService implements iCustomer{

	public String generateCustID(){
		return "C"+ Math.round(Math.random()*999999999);
	}
	@Override
	public Customer addCustomer(String name, String address) {		
		return new Customer(generateCustID(), name, address);
	}	
}
